# Coding Challenge II

Congratulations on completing the first coding test! The first quiz
tested you on the basics of programming. This second challenge is
meant to measure your ability to solve problems with code.

## When should I take the test?

The test will take up to 1 hour. Please have time set aside so that
you can complete the test unhurried by other commitments.

Do **take your time in preparing for the test** so that you may do
your best. There is no hurry. You may take it whenever you like.

## What programming language do I write in?

We have designed the test in Ruby, which is the language of Rails.

You may also answer the challenge in Python, if you choose. If you do
not know Python, please complete the challenge in Ruby.

If you know another language and would strongly prefer to answer in
that, please contact [us](mailto:admissions@appacademy.io).

#### Outside sources

**Please** do not search Google for answers to the
problems. **Please do not post our problems to the internet**.
