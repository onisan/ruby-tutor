def ordered_vowel_words(str)
end
