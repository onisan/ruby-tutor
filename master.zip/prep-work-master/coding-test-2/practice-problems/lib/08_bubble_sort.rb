def bubble_sort(arr)
end
